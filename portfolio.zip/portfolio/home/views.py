from django.shortcuts import render,HttpResponse
from home.models import Contac

# Create your views here.

def home(request):
    # return HttpResponse("Hi this is my home page")
    context={'name':'Santhosh','course':'Django'}
    return render(request,'home.html',context)

def about(request):
    # return HttpResponse("this is my about page")
    return render(request,'about.html')

def project(request):
    return render(request,'project.html')

def contact(request):
    # return HttpResponse("This is my contact page")
    if request.method=="POST":
        name=request.POST['name']
        email=request.POST['email']
        phone=request.POST['phone']
        text=request.POST['text']
        ins=Contac(name=name,email=email,phone=phone,text=text)
        ins.save()
        
    
    return render(request,'contact.html')