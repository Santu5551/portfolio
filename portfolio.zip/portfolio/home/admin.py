from django.contrib import admin
from home.models import Contac

# Register your models here.
admin.site.register(Contac)

